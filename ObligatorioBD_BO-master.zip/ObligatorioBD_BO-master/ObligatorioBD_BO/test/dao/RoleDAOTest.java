/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.HashMap;
import models.Role;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author juanizquierdo
 */
public class RoleDAOTest {
    
    public RoleDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createRole method, of class RoleDAO.
     */
    @Test
    public void testCreateRole() {
        System.out.println("createRole");
        String ID = "";
        String name = "";
        RoleDAO instance = new RoleDAO();
        /*int expResult = 0;
        int result = instance.createRole(ID, name);*/
        /* assertEquals(expResult, result);*/
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateRole method, of class RoleDAO.
     */
    @Test
    public void testUpdateRole() {
        System.out.println("updateRole");
        Role role = null;
        RoleDAO instance = new RoleDAO();
        int expResult = 0;
        /*int result = instance.updateRole(role);
        assertEquals(expResult, result);*/
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insertRole method, of class RoleDAO.
     */
    @Test
    public void testInsertRole() {
        System.out.println("insertRole");
        Role role = null;
        RoleDAO instance = new RoleDAO();
        /*int expResult = 0;
        int result = instance.insertRole(role);*/
        /* assertEquals(expResult, result);*/
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteRole method, of class RoleDAO.
     */
    @Test
    public void testDeleteRole() {
        System.out.println("deleteRole");
        Role role = null;
        RoleDAO instance = new RoleDAO();
        int expResult = 0;
        /*int result = instance.deleteRole(role);
        assertEquals(expResult, result);*/
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selectRole method, of class RoleDAO.
     */
    @Test
    public void testSelectRole() {
        System.out.println("selectRole");
        RoleDAO instance = new RoleDAO();
        HashMap<Integer, String> expResult = null;
        HashMap<Integer, String> result = instance.selectRole();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
