/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Agroa
 */
public class UserDAOTest {
    
    public UserDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of updateUser method, of class UserDAO.
     */
    @Test
    public void testUpdateUser() {
        System.out.println("updateUser");
        String usuario = "emmanuel";
        String contrasena = "Emmanuel";
        UserDAO instance = new UserDAO();
        boolean expResult = true;
        //boolean result = instance.updateUser(usuario,contrasena);
        //assertEquals(expResult, result);
    }

    /**
     * Test of logIn method, of class UserDAO.
     */
    @Test
    public void testLogIn() {
        System.out.println("logIn");
        String usuario = "emmanuel";
        String contrasena = "Emmanuel";
        UserDAO instance = new UserDAO();
        int expResult = 100;
        //int result = instance.logIn(usuario, contrasena);
        //assertEquals(expResult, result);
    }


    /**
     * Test of insertUser method, of class UsuarioDAO.
     */
    @Test
    public void testInsertUser() {
        System.out.println("insertUser");
        String usuario = "jabal";
        String contrasena = "jabal";
        UserDAO instance = new UserDAO();
        boolean expResult = true;
        String[] atributos = {"gbergessio","bolsobolso","48568565"};
        //boolean result = instance.insertUser(usuario,contrasena,atributos);
        //assertEquals(expResult, result);
    }

    /**
     * Test of deleteUser method, of class UsuarioDAO.
     */
    @Test
    public void testDeleteUser() {
        System.out.println("deleteUser");
        String usuario = "emmanuel";
        String contrasena = "Emmanuel";
        UserDAO instance = new UserDAO();
        boolean expResult = true;
        //boolean result = instance.deleteUser(usuario,contrasena);
        //assertEquals(expResult, result);
    }

    /**
     * Test of selectUser method, of class UsuarioDAO.
     */
    @Test
    public void testSelectUser() {
        System.out.println("selectUser");
        String usuario = "emmanuel";
        String contrasena = "Emmanuel";
        UserDAO instance = new UserDAO();
        boolean expResult = true;
        boolean result = instance.selectUser(usuario,contrasena);
        assertEquals(expResult, result);
    }

    /**
     * Test of createUser method, of class UserDAO.
     */
    @Test
    public void testCreateUser() {
        System.out.println("createUser");
        String user = "emmanuel";
        String contrasenaUser = "Emmanuel";
        String usuario = "ramaral";
        String contrasena = "ramarama";
        UserDAO instance = new UserDAO();
        String expResult = "OK";
        String result = instance.createUser(usuario, contrasena,user,contrasenaUser);
        assertEquals(expResult, result);
    }
    
}
