/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.HashMap;
import models.CodeResponse;
import models.Role;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author juanizquierdo
 */
public class RoleControllerTest {

    public RoleControllerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of createRole method, of class RoleController.
     */
    @Test
    public void testCreateRole() {
        System.out.println("createRole");
        Role role = null;
        RoleController instance = new RoleController();
        CodeResponse expResult = null;
        CodeResponse result = instance.createRole(role);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateRole method, of class RoleController.
     */
    @Test
    public void testUpdateRole() {
        System.out.println("updateRole");
        Role role = null;
        RoleController instance = new RoleController();
        CodeResponse expResult = null;
        CodeResponse result = instance.updateRole(role);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selectRole method, of class RoleController.
     */
    @Test
    public void testSelectRole() {
        System.out.println("selectRole");
        RoleController instance = new RoleController();
        HashMap<Integer, String> expResult = null;
        HashMap<Integer, String> result = instance.selectRole();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteRole method, of class RoleController.
     */
    @Test
    public void testDeleteRole() {
        System.out.println("deleteRole");
        Role role = null;
        RoleController instance = new RoleController();
        CodeResponse expResult = null;
        CodeResponse result = instance.deleteRole(role);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}
