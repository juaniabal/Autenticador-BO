/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author juanizquierdo
 */
public class Functionality {

    private int idFunc;
    private String nombreFunc;
    private int idMenu;

    /**
     * Clase Funcionalidad.
     *
     * @param idFunc
     * @param nombreFunc
     * @param idMenu
     */
    public Functionality(int idFunc, String nombreFunc, int idMenu) {
        this.idFunc = idFunc;
        this.nombreFunc = nombreFunc;
        this.idMenu = idMenu;
    }
    public Functionality(){
        
    }
    public void setIdMenu(int idmenu){
        this.idMenu = idmenu;
    }
    /**
     *
     * @return
     */
    public int getIdFunc() {
        return idFunc;
    }

    /**
     *
     * @return
     */
    public String getNombreFunc() {
        return nombreFunc;
    }

    /**
     *
     * @param idFunc
     */
    public void setIdFunc(int idFunc) {
        this.idFunc = idFunc;
    }

    /**
     *
     * @param nombreFunc
     */
    public void setNombreFunc(String nombreFunc) {
        this.nombreFunc = nombreFunc;
    }

    /**
     *
     * @return
     */
    public int getIdMenu() {
        return this.idMenu;
    }

}
