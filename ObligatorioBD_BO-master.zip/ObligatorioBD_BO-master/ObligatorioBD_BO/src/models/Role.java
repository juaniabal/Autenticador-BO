/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author juanizquierdo
 */
public class Role {

    private int idRole;
    private String name;

    /**
     * Clase Rol.
     *
     * @param idRole
     * @param name
     */
    public Role(int idRole, String name) {
        this.idRole = idRole;
        this.name = name;
    }

    /**
     *
     */
    public Role() {
        this.idRole = 0;
        this.name = "";
    }

    /**
     *
     * @return
     */
    public int getId() {
        return idRole;
    }

    /**
     *
     * @param idRole
     */
    public void setId(int idRole) {
        this.idRole = idRole;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

}
