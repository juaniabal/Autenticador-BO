/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.security.InvalidKeyException;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author Eacosta
 */
public class Cypher {
      private static final String KEY = "7977777777777777";
      
      
      public static String encrypt(String input) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
          byte[] crypted = null;
          try{
              SecretKeySpec skey = new SecretKeySpec(KEY.getBytes(),"AES");
              Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
              cipher.init(Cipher.ENCRYPT_MODE,skey);
              crypted = cipher.doFinal(input.getBytes());
              
          }catch(Exception e){
              System.out.println(e.toString());
          }return new String(Base64.getEncoder().encode(crypted));
      }
      
       public static String decrypt(String input) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
          byte[] output = null;
          try{
              SecretKeySpec skey = new SecretKeySpec(KEY.getBytes(),"AES");
              Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
              cipher.init(Cipher.ENCRYPT_MODE,skey);
              output = cipher.doFinal(Base64.getDecoder().decode(input));
              
          }catch(Exception e){
              System.out.println(e.toString());
          }return new String(output);
      }
}
