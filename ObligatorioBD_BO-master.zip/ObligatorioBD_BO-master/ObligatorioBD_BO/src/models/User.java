/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.Date;

/**
 *
 * @author Agroa
 */
public class User {
    private int[] roles;
    private int cedula;
    private String nombreApellido;
    private String email;
    private String telefono;
    private String primerautorizador;
    private String segundoAutorizador;
    private Date fechaPrimerAu;
    private Date fechaSegundoAu;
    private Date fechaAut;
    private int codigoAut;
    private String nomUsu;
    private String estado;

    /**
     * @return the roles
     */
    public int[] getRoles() {
        return roles;
    }

    /**
     * @param roles the roles to set
     */
    public void setRoles(int[] roles) {
        this.roles = roles;
    }

    /**
     * @return the cedula
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @param cedula the cedula to set
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     * @return the nombreApellido
     */
    public String getNombreApellido() {
        return nombreApellido;
    }

    /**
     * @param nombreApellido the nombreApellido to set
     */
    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the primerautorizador
     */
    public String getPrimerautorizador() {
        return primerautorizador;
    }

    /**
     * @param primerautorizador the primerautorizador to set
     */
    public void setPrimerautorizador(String primerautorizador) {
        this.primerautorizador = primerautorizador;
    }

    /**
     * @return the segundoAutorizador
     */
    public String getSegundoAutorizador() {
        return segundoAutorizador;
    }

    /**
     * @param segundoAutorizador the segundoAutorizador to set
     */
    public void setSegundoAutorizador(String segundoAutorizador) {
        this.segundoAutorizador = segundoAutorizador;
    }

    /**
     * @return the fechaPrimerAu
     */
    public Date getFechaPrimerAu() {
        return fechaPrimerAu;
    }

    /**
     * @param fechaPrimerAu the fechaPrimerAu to set
     */
    public void setFechaPrimerAu(Date fechaPrimerAu) {
        this.fechaPrimerAu = fechaPrimerAu;
    }

    /**
     * @return the fechaSegundoAu
     */
    public Date getFechaSegundoAu() {
        return fechaSegundoAu;
    }

    /**
     * @param fechaSegundoAu the fechaSegundoAu to set
     */
    public void setFechaSegundoAu(Date fechaSegundoAu) {
        this.fechaSegundoAu = fechaSegundoAu;
    }

    /**
     * @return the fechaAut
     */
    public Date getFechaAut() {
        return fechaAut;
    }

    /**
     * @param fechaAut the fechaAut to set
     */
    public void setFechaAut(Date fechaAut) {
        this.fechaAut = fechaAut;
    }

    /**
     * @return the codigoAut
     */
    public int getCodigoAut() {
        return codigoAut;
    }

    /**
     * @param codigoAut the codigoAut to set
     */
    public void setCodigoAut(int codigoAut) {
        this.codigoAut = codigoAut;
    }

    /**
     * @return the nomUsu
     */
    public String getNomUsu() {
        return nomUsu;
    }

    /**
     * @param nomUsu the nomUsu to set
     */
    public void setNomUsu(String nomUsu) {
        this.nomUsu = nomUsu;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
