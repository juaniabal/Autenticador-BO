/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import controller.ScreenController;
import dao.LogDAO;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author Agroa
 */
public class TableExample {

    JFrame f;

    public TableExample() {
        f = new JFrame();
        LogDAO lg = new LogDAO();
        ArrayList<String[]> datos = lg.selectLogs();
        
        String data[][] = new String[datos.size()][11];
        for(int i = 0 ; i<datos.size();i++){
            data[i] = datos.get(i);
        }
        String column[] = {"IDLOG", "USUARIO AC>TUAL", "FECHA CAMBIO", "USUARIO" , "ID FUNCIONALIDAD", "ID APLICACION","ID TIPO EVENTO","DESCRIPCION LARGA","DESCRIPCION CORTA","IDROL","ID MENU"};
        JTable jt = new JTable(data, column);
        jt.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(jt);
        JMenu jm = new JMenu();
        JMenuItem mi = new JMenuItem("Pantalla Principal");
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                ScreenController sc = new ScreenController();
                sc.hideScreen(f);
                sc.showMainScreen();
            }
        };
        mi.addActionListener(al);
        jm.add(mi);
       JMenuBar menuBar;
        JMenu m_file;
        JMenuItem mi_save;
        

        
        JMenuItem mi_tileHeight;
        JMenuItem mi_tileWidth;

        menuBar = new JMenuBar();
        m_file = new JMenu("Pantalla Principal");
        

        mi_save = new JMenuItem("Volver Pantalla Principal", KeyEvent.VK_S);
        ;
        mi_tileHeight = new JMenuItem("Set tile height",
        KeyEvent.VK_H);
        mi_tileWidth = new JMenuItem("Set tile width",
        KeyEvent.VK_W);

        menuBar.add(m_file);
        m_file.add(mi_save);
        
        mi_save.addActionListener(al);

        
        
        
        f.setJMenuBar(menuBar);
        
        
        f.add(sp);
        f.setSize(300, 400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
