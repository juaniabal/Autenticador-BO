/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class UtilsDAO {

    DatabaseConnection dbconn = DatabaseConnection.getInstance();
    private String selectRoleUser = "SELECT * FROM VW_QRY_PENDING_ROLE_USER WHERE nomusu = ";
    private String selectUserApp = "SELECT * FROM VW_QRY_PENDING_USER_APP WHERE NOMUSU = ";
    public boolean checkPendingAuthorizations(String nomusu) {
        boolean resultado = false;
        boolean resultado2 = false;
        Connection con;
        con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery(selectRoleUser + "'" + nomusu + "'");
            if(rs.next()){
                resultado = true;
            }
            rs = s.executeQuery(selectUserApp + "'" + nomusu + "'");
            if(rs.next()){
                resultado2 = true;
            }
            return resultado||resultado2;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}
