/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.HashMap;
import models.Role;

/**
 *
 * @author juanizquierdo
 */
public interface IRoleDAO {

    /**
     * Metodo que crea un Rol en la tabla Rol
     *
     * @param ID
     * @param name
     * @return
     */
    int[] createRole(String ID, String name);

    /**
     * Funcion que hace una actualizacion en un Rol en la tabla Rol.
     *
     * @param role
     * @return
     */
    int[] updateRole(Role role);

    /**
     * Funcion que inserta un Rol en la tabla Rol.
     *
     * @param role
     * @return
     */
    int[] insertRole(Role role);

    /**
     * Funcion que hace una baja logica de un Rol en la tabla Rol.
     *
     * @param role
     * @return
     */
    int[] deleteRole(Role role);

    /**
     * Funcion que selecciona todos los roles de la tabla Rol.
     *
     * @return
     */
    HashMap<Integer, String> selectRole();
}
