/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class UserApplicationDAO implements IUserApplicationDAO {

    DatabaseConnection dbConn = DatabaseConnection.getInstance();
    private String insert = "INSERT INTO ROL_USUARIO VALUES (";
    private String insertUsuApp = "INSERT INTO USU_APLICACION (idaplicacion, usu_apl_nomusu,reg_status) VALUES(";
    private String update = "UPDATE usu_aplicacion SET REG_STATUS = 0";
    private String updateUser = "UPDATE USUARIO SET SEGUNDOAUTORIZADOR = ";
    private String updateReg1 = "update usu_aplicacion set reg_status = 1";
    private String currentApps = "SELECT * FROM VW_QRY_USER_APPS WHERE NOMUSU = ";
    private String deleteUserApp = "DELETE FROM USU_APLICACION WHERE ";
    private String insertDelete = "INSERT INTO USU_APLICACION (REG_STATUS,DELETEUA) VALUES (";
    private String updateDelete = "UPDATE usu_aplicacion SET DELETEUA = ";
    private String checkAvailable = "SELECT * FROM USUARIO WHERE NOMUSU = ";
    private String updateUserFirst = "UPDATE USUARIO SET PRIMERAUTORIZADOR = ";

    @Override
    public boolean selectUserApps(String usuario, int idApp) {
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            boolean tiene = false;
            ResultSet rs = s.executeQuery("select * from usu_aplicacion where usu_apl_nomusu = '" + usuario + "' and idaplicacion = " + idApp);
            while (rs.next()) {
                tiene = true;
            }
            return tiene;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return true;
        }
    }

    @Override
    public int[] updateUserApps(String nomusu, int idAplicacion) {
        int[] result = null;
        Connection con = null;
        try {
            con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(update + " where idaplicacion = " + idAplicacion + " and usu_apl_nomusu = '" + nomusu + "'");
            s.addBatch(updateUser + "'" + dbConn.getUser() + "' where nomusu = '" + nomusu + "'");
            result = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            lc.insertLogUserApp(nomusu, dbConn.getUser(), 4, "El usuario " + dbConn.getUser() + " ha confirmado la aplicacion " + idAplicacion + " al usuario " + nomusu, "Upgrade app user", idAplicacion);
            boolean check = udao.checkPendingAuthorizations(nomusu);
            if (check) {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            } else {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            }
            con.commit();
            return result;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            e.getNextException();
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            return result;
        }
    }

    @Override
    public int[] insertUserApps(String[] usuApp, String user) {
        Connection conn = dbConn.getCurrentConnection();
        try {
            
            Statement s = conn.createStatement();
            for (String strRolUsu : usuApp) {
                String[] splitUsuApp = strRolUsu.split("-");
                s.addBatch(insertUsuApp +  splitUsuApp[0] + ",'" + user + "'" +",1)");
            }
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            for (String strUsuApp : usuApp) {
                String[] splitUsuApp = strUsuApp.split("-");
                lc.insertLogUserApp(user, dbConn.getUser(), 3, "El usuario " + dbConn.getUser() + " ha agregado la aplicacion " + splitUsuApp[0] + " al usuario " + user, "Upgrade rol user", Integer.parseInt(splitUsuApp[0]));
            }
            boolean check = udao.checkPendingAuthorizations(user);
            if (check) {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + user + "'");
                s.addBatch(updateUserFirst + "'" + dbConn.getUser()  + "' where nomusu = '" + user + "'" );
                s.executeBatch();
            }/* else {
            s.clearBatch();
            s.addBatch(updateUser + "null" + " where nomusu = '" + user + "'");
            s.addBatch(updateUserFirst + "null" + " where nomusu = '" + user + "'");
            s.executeBatch();
            }*/
            conn.commit();
            return batch;
        } catch (SQLException ex) {
            ex.getNextException();
              try {
                conn.rollback();
            } catch (SQLException e) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public int[] deleteUserApps(String nomusu, int idaplicacion) {
        Connection conn = dbConn.getCurrentConnection();
        try {
            Statement s = conn.createStatement();
            String updateDeleteNew = updateDelete + "'" + deleteUserApp + "usu_apl_nomusu = ''"
                    + nomusu + "'' and idaplicacion = " + idaplicacion + "'" + " where usu_apl_nomusu = '" + nomusu + "' and idaplicacion = " + idaplicacion;
            s.addBatch(updateDeleteNew);
            s.addBatch(updateReg1 + " where usu_apl_nomusu = '" + nomusu + "' and idaplicacion = " + idaplicacion);
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();

            lc.insertLogUserApp(nomusu, dbConn.getUser(), 6, "El usuario " + dbConn.getUser() + " ha quitado la aplicacion " + idaplicacion + " al usuario " + nomusu, "Downgrade app user", idaplicacion);

            boolean check = udao.checkPendingAuthorizations(nomusu);
            if (check) {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            } else {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            }
            conn.commit();
            return batch;
        } catch (SQLException ex) {
            ex.getNextException();
            Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        return null;
    }

    @Override
    public ArrayList<String> currentApps(String nomusu) {
        try {
            ArrayList<String> data = new ArrayList<>();
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery(currentApps + "'" + nomusu + "'");

            while (rs.next()) {
                data.add(rs.getInt("idaplicacion") + "-" + rs.getString("nombre"));
            }
            return data;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] deletePermantly(String usuApp, int idAplicacion) {
        Connection conn = dbConn.getCurrentConnection();
        try {
            Statement s = conn.createStatement();

            s.addBatch(deleteUserApp + "usu_apl_nomusu = '" + usuApp + "' and idaplicacion = " + idAplicacion);
            s.addBatch(updateUser + "'" + dbConn.getUser() + "' where nomusu = '" + usuApp + "'");
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            lc.insertLogRoleUser(usuApp, dbConn.getUser(), 6, "El usuario " + dbConn.getUser() + " ha eliminado permanentemente la aplicacion " + idAplicacion + " al usuario " + usuApp, "Downgrade app user", idAplicacion);
            boolean check = udao.checkPendingAuthorizations(usuApp);
            if (check) {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + usuApp + "'");
                s.executeBatch();
            } else {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + usuApp + "'");
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + usuApp + "'");
                s.executeBatch();
            }
            conn.commit();
            return batch;
        } catch (SQLException ex) {
            Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        return null;
    }

    @Override
    public boolean checkAvailable(String userName) {
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            boolean available = true;
            ResultSet rs = s.executeQuery(checkAvailable + "'" + userName + "' and primerautorizador is not null and segundoautorizador is null");
            while (rs.next()) {
                available = false;
            }

            return available;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

}
