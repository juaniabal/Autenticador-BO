/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;

/**
 *
 * @author Agroa
 */
public interface IUserApplicationDAO {
    boolean selectUserApps(String usuario, int idApp);
    int[] updateUserApps(String usuApp,int idAplicacion);
    int[] insertUserApps(String[] usuApp,String user);
    int[] deleteUserApps(String nomusu,int idaplicacion);
    ArrayList<String> currentApps(String nomusu);
    int[] deletePermantly(String usuApp, int idAplicacion);
     boolean checkAvailable(String userName);
}
