/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class InboxDao implements IInboxDAO {

    DatabaseConnection dbConn = DatabaseConnection.getInstance();
    private String selectPendigAutRoleUser = "select * from vw_qry_pending_role_user where primerautorizador <> ";
    private String selectPendigAutUserApp = "select * from vw_qry_pending_user_app where primerautorizador <> ";
    private String selectPendingAutUsers = "select * from usuario where reg_status = 1 and (primerautorizador is null or primerautorizador <> ";

    @Override
    public ArrayList<String> selectPendingAuthorizationRoleUser() {
        ArrayList<String> arrPendings = new ArrayList<String>();
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery(selectPendigAutRoleUser + "'" + dbConn.getUser()+ "'");
            while (rs.next()) {
                arrPendings.add(rs.getString("nomusu") + "-" + rs.getString("nombre") + "-" + rs.getInt("idrol") +"-" + rs.getString("deleteru") );
            }

            return arrPendings;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public ArrayList<String> selectPendingAuthorizationUserApps() {
        ArrayList<String> arrPendings = new ArrayList<String>();
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery(selectPendigAutUserApp + "'" + dbConn.getUser()+ "'");
            while (rs.next()) {
                arrPendings.add(rs.getString("nomusu") + "-" + rs.getString("nombre") + "-" + rs.getInt("idaplicacion") +"-" + rs.getString("deleteua"));
            }

            return arrPendings;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public boolean selectPendingAuthorizationRoleMenus() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> selectPendingAuthorizationUsers() {
       ArrayList<String> arrPendings = new ArrayList<>();
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery(selectPendingAutUsers + "'" + dbConn.getUser()+ "')");
            while (rs.next()) {
                arrPendings.add(rs.getString("nomusu")  + "-" + rs.getString("deleteuser"));
            }
            

            return arrPendings;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

}
