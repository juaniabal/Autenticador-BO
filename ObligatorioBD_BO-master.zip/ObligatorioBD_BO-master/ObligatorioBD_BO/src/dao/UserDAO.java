/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class UserDAO implements IUserDAO {

    private final String update = "UPDATE USUARIO SET ";
    private final String select = "SELECT * FROM USUARIO WHERE ";
    private final String insert = "INSERT INTO USUARIO (nomusu,contrasena,ci_persona,idestado,primerautorizador,fechaprimerautorizacion,reg_status) values ";
    private String delete = "DELETE FROM USUARIO WHERE ";
    private String updateDelete = "UPDATE usuario SET DELETEUSER = ";
    private String deleteUser = "DELETE FROM USUARIO WHERE ";
    private String updateReg1 = "update usuario set reg_status = 0";
    private String updateReg0 = "update usuario set reg_status = 1";
    private String updateUser = "UPDATE USUARIO SET SEGUNDOAUTORIZADOR = ";
    private String user = null;
    private String contrasena = "";
    private String updateUserFirst = "UPDATE USUARIO SET PRIMERAUTORIZADOR = ";
    LogDAO log = new LogDAO();
    DatabaseConnection dbconn = DatabaseConnection.getInstance();

    private String createPerson = "insert into persona (ci_persona,nombre,apellido,telefono,email) values (";

    @Override
    public boolean updateUser(String usuario) {
        Connection con = null;
        try {

            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(updateUser + "'" + dbconn.getUser() + "' where nomusu = '" + usuario + "'");
            s.addBatch(updateReg1 + " where nomusu = '" + usuario + "'");
            s.executeBatch();
            s.clearBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();

            lc.insertLogUser(usuario, dbconn.getUser(), 1, "El usuario " + dbconn.getUser() + " ha confirmado la creación del usuario:  " + usuario, "Create user");

            boolean check = udao.checkPendingAuthorizations(usuario);
            if (check) {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + usuario + "'");
                s.executeBatch();
            } else {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + usuario + "'");
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + usuario + "'");
                s.executeBatch();
            }
            con.commit();
            JOptionPane.showMessageDialog(null, "Se actualizó el usuario correctamente");
            return true;
        } catch (SQLException e) {
             try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public int logIn(String usuario, String contrasena) {
        Connection con = null;
        try {
            dbconn.setUser(usuario);
            dbconn.setPassword(contrasena);
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery("select * from usuario");
            return 100;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            if (e.getMessage().contains("password authentication")) {
                return 101;
            } else if (e.getMessage().contains("El intento de conexión falló")) {
                return 102;
            } else {
                return 103;
            }

        }
    }

    @Override
    public int insertUser(String insert, String[] attributes) {
        Connection con = dbconn.getCurrentConnection();
        try {

            
            Statement s = con.createStatement();
            s.addBatch(insert);
            int[] result = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();

            lc.insertLogUser(attributes[0], dbconn.getUser(), 1, "El usuario " + dbconn.getUser() + " ha creado al usuario " + attributes[0], "Create user");

            boolean check = udao.checkPendingAuthorizations(attributes[0]);
            // if (check) {
            s.clearBatch();
            s.addBatch(updateUser + "null" + " where nomusu = '" + attributes[0] + "'");
            s.executeBatch();
            /*            } else {
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + attributes[0] + "'");
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + attributes[0] + "'");
                s.executeBatch();
                }*/
            con.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");

            return result[0];
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            if (e.getMessage().contains("La consulta no retorno ning")) {
                return 100;
            }

            try {
                throw new Exception(e);
            } catch (Exception ex) {
                Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(e.getMessage());
            return 101;
        }
    }

    @Override
    public int[] deleteUser(String usuario) {
        Connection conn = null;
        try {
            conn = dbconn.getCurrentConnection();
            UtilsDAO udao = new UtilsDAO();
            boolean aut = udao.checkPendingAuthorizations(usuario);
            Statement s = conn.createStatement();
            String updateDeleteNew = updateDelete + "'" + deleteUser + "nomusu = ''"
                    + usuario + "'" + " where nomusu = '" + usuario + "'";
            if(!aut){
                String updatePrimer = "update usuario set primerautorizador = '" + dbconn.getUser() +"' where nomusu = '" + usuario + "'";
                s.addBatch(updatePrimer);
            }
            String updateReg = updateReg0 + " where nomusu = '" + usuario + "'";
            s.addBatch(updateReg);
            s.addBatch(updateDeleteNew);
            
            //s.addBatch(updateReg1 + " where usu_apl_nomusu = '" + nomusu + "' and idaplicacion = " + idaplicacion);
            int[] batch = s.executeBatch();
            
            LogController lc = new LogController();

            lc.insertLogUser(usuario, dbconn.getUser(), 2, "El usuario " + dbconn.getUser() + " ha eliminado al usuario " + usuario, "Delete user");

            s.clearBatch();
            s.addBatch(updateUser + "null" + " where nomusu = '" + usuario + "'");
            s.executeBatch();

            conn.commit();
            JOptionPane.showMessageDialog(null, "Se eliminó al usuario");
            return batch;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Operación incorrecta");
            ex.getNextException();
            Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        return null;
    }

    public int[] deletePermantly(String usuApp) {
        Connection conn = dbconn.getCurrentConnection();
        try {
            Statement s = conn.createStatement();

            s.addBatch(deleteUser + "nomusu = '" + usuApp + "'");
            //s.addBatch(updateUser + "'" + dbConn.getUser() + "' where nomusu = '" + usuApp + "'");
            int[] batch = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogUser(null, dbconn.getUser(), 2, "El usuario " + dbconn.getUser() + " ha eliminado permanentemente al usuario " + usuApp, "Delete permanently user");
            conn.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return batch;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Operación incorrecta");
            Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(UserApplicationDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
            ex.getNextException();
        }
        return null;
    }

    @Override
    public boolean selectUser(String usuario, String contrasena) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from usuario");
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * Metodo que crea un usuario en pg_user
     *
     * @param user
     * @param usuario
     * @param contrasena
     * @return
     */
    @Override
    public String createUser(String currentUser, String currentPassword, String usuario, String contrasenaUsuario) {
        this.user = currentUser;
        String createUser = "create user " + usuario + " with password '" + contrasenaUsuario + "'";
        String addRole = "grant standardUser to " + usuario.replace("\"", "");
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            /* s.addBatch(createUser);
            s.addBatch(addRole);
            s.executeBatch();*/
            boolean rs = s.execute(createUser);
            boolean rs2 = s.execute(addRole);
            boolean result = rs && rs2;
            //con.commit();
            //rs.close();
            //s.close();
            
            return "OK";
            
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            return e.getMessage();
        }
    }

    @Override
    public String createPerson(String usuario, String contrasena, String[] attributes) {
        this.user = usuario;
        Connection con = null;
        try {
            String values = "";
            values += attributes[0];
            for (int i = 1; i < attributes.length; i++) {
                if (i == 3) {
                    values += " " + attributes[i];
                } else {
                    values += " '" + attributes[i] + "'";
                }
            }
            values = values.trim();
            values = values.replace(' ', ',');
            values += ")";
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            createPerson += values;
            s.clearBatch();
            s.addBatch(createPerson);
            s.executeBatch();
            con.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return "OK";
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Operación incorrecta");
            System.out.println(e.getMessage());
            e.getNextException();
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (e.getMessage().contains("La consulta no ret")) {
                return "OK";
            } else {
                return "not OK";
            }
        }
    }

    @Override
    public boolean addRole(String user, String role) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> selectPersonas() {
         Connection con = null;
         ArrayList<String> persona = new ArrayList<>();
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from persona");
            while(rs.next()){
                persona.add(rs.getString("nombre") + " - " + rs.getString("apellido")+ " - C.I: " + rs.getInt("ci_persona"));
            }
            return persona;
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(e.getMessage());
            return null;
        }
    }

}
