/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;

/**
 *
 * @author Agroa
 */
public interface IUserDAO {
    
    /**
     * Funcion que realiza la prueba de logueo del usuario.
     * @param usuario
     * @param contrasena
     * @return 
     */
    int logIn(String usuario, String contrasena);

    /**
     *
     * @param user
     * @param contrasena
     * @param usuario
     * @param contrasenaUsuario
     * @return
     */
    String createUser(String user,String contrasena,String usuario,String contrasenaUsuario);
    /**
     * Funcion que hace una actualizacion en un usuario en la tabla Usuario.
     * @return 
     */
    boolean updateUser(String usuario);

    /**
     * Funcion que inserta un usario en la tabla Usuario.
     * @return 
     */
    int insertUser(String insert,String[] attributes);

    /**
     * Funcion que hace una baja logica de un usuario en la tabla Usuario.
     * @return 
     */
    int[] deleteUser(String usuario);

    /**
     * Funcion que selecciona un usuario de la tabla Usuario.
     * @return 
     */
    boolean selectUser(String usuario, String contrasena);
    
    /**funcion que crea una persona en la tabla persona
     * 
     * @param usuario
     * @param contrasena
     * @param atributos
     * @return 
     */
    String createPerson(String usuario, String contrasena,String[] atributos);
    
    boolean addRole(String user, String role);
    
    ArrayList<String> selectPersonas();
}
