/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.HashMap;
import models.Application;
import models.Menu;

/**
 *
 * @author Agroa
 */
public interface IApplicationDAO {
    int[] insertApplication(Application application);
    int[] updateApplication(Application application);
    HashMap<Integer,String> selectApplication();
    int[] deleteApplication(Application application);
}
