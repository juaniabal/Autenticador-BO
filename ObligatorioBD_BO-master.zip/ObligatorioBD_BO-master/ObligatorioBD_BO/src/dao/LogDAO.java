/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class LogDAO implements ILogDAO {

    DatabaseConnection dbConn = DatabaseConnection.getInstance();
    private String insertLogUser = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_NOM_USU_USUARIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";
    private String insertLogUserDelete = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";
    private String insertLogRoleUser = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_NOM_USU_USUARIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,IDROL) VALUES ";
    private String insertLogUserApp = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_NOM_USU_USUARIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,LOG_IDAPLICACION) VALUES ";
    private String insertLogRole = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,IDROL) VALUES ";
    private String insertLogRoleDelete = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";
    private String insertLogAplicacion = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,LOG_IDAPLICACION) VALUES ";
    private String insertLogAplicacionDelete = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";
    private String insertLogMenu = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,idmenu) VALUES ";
    private String insertLogMenuDelete = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";
    private String insertLogRolMenu = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,IDROL,idmenu) VALUES ";
    private String insertLogRolMenuDelete = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";
    private String insertLogFunctionality = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA,LOG_IDFUNCIONALIDAD) VALUES ";
    private String insertLogFunctionalityDelete = "INSERT INTO LOGS (IDLOG,LOG_NOMUSU_ACTUAL,FECHACAMBIO,LOG_IDTIPOEVENTO,DESC_LARGA,DESC_CORTA) VALUES ";

    @Override
    public int selectSequence() {
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            int dual = 0;
            ResultSet rs = s.executeQuery("SELECT nextval('serie_log') as dual;");
            if (rs.next()) {
                dual = rs.getInt("dual");
            }
            return dual;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    @Override
    public int[] insertLogUser(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta) {
        //int sequence = this.selectSequence();
        Date date = new Date(System.currentTimeMillis());
        String values = "";
        if (tipoEvento != 2) {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD'),'" + nomusu + "',"+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        } else {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" + ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        }
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            if (tipoEvento != 2) {
                s.addBatch(insertLogUser + values);
            } else {
                s.addBatch(insertLogUserDelete + values);
            }
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogRole(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idrol) {
        Date date = new Date(System.currentTimeMillis());
        String values = "";
        if (tipoEvento != 8) {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" + ","+ tipoEvento + ",'"+ descLarga + "','" + descCorta + "'," + idrol + ")";
        } else {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" + ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        }
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            if (tipoEvento != 8) {
                s.addBatch(insertLogRole + values);
            } else {
                s.addBatch(insertLogRoleDelete + values);
            }
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogFunctionality(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idFunc) {
        Date date = new Date(System.currentTimeMillis());
        String values = "";
        if (tipoEvento != 19) {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')"+","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "'," + idFunc + ")";
        } else {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')"+","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        }
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            if (tipoEvento != 19) {
                s.addBatch(insertLogFunctionality + values);
            } else {
                s.addBatch(insertLogFunctionalityDelete + values);
            }
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogMenu(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idmenu) {
        Date date = new Date(System.currentTimeMillis());
        String values = "";
        if (tipoEvento != 14) {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')"+ ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "'," + idmenu + ")";
        } else {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')"+ ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        }
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            if (tipoEvento != 14) {
                s.addBatch(insertLogMenu + values);
            } else {
                s.addBatch(insertLogMenuDelete + values);
            }
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogApplication(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idAplicacion) {
        Date date = new Date(System.currentTimeMillis());
        String values = "";
        if (tipoEvento != 11) {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" + ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "'," + idAplicacion + ")";
        } else {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" + ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        }
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            if (tipoEvento != 11) {
                s.addBatch(insertLogAplicacion + values);
            } else {
                s.addBatch(insertLogAplicacionDelete + values);
            }
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogUserApp(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idAplicacion) {
        Date date = new Date(System.currentTimeMillis());
        String values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD'),'" + nomusu +  "',"+ tipoEvento + ",'" + descLarga + "','" + descCorta + "'," + idAplicacion + ")";
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            s.addBatch(insertLogUserApp + values);
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogRoleUser(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idRol) {
        Date date = new Date(System.currentTimeMillis());
        String values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD'),'" + nomusu +  "',"+ tipoEvento + ",'" + descLarga + "','" + descCorta + "'," + idRol + ")";
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            s.addBatch(insertLogRoleUser + values);
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogRolMenu(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idRol, int idMenu) {
        Date date = new Date(System.currentTimeMillis());
        String values = "";
        if (tipoEvento != 17) {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" +","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "'," + idRol + "," + idMenu + ")";
        } else {
            values = "(" + "nextval('serie_log')" + ",'" + dbConn.getUser() + "',to_date('" + date + "','YYYY/MM/DD')" + ","+ tipoEvento + ",'" + descLarga + "','" + descCorta + "')";
        }
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            if (tipoEvento != 17) {
                s.addBatch(insertLogRolMenu + values);
            } else {
                s.addBatch(insertLogRolMenuDelete + values);
            }
            return s.executeBatch();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertLogPerson(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ArrayList<String[]> selectLogs() {
        ArrayList<String[]> logs = new ArrayList<>();
        Connection con = dbConn.getCurrentConnection();
        try {

            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("Select * from logs");
            while(rs.next()){
                String[] arrayTemp = new String[11];
                arrayTemp[0] = String.valueOf(rs.getInt("idlog"));
                arrayTemp[1] = rs.getString("log_nomusu_actual");
                arrayTemp[2] = String.valueOf(rs.getDate("fechacambio"));
                arrayTemp[3] = rs.getString("log_nom_usu_usuario");
                arrayTemp[4] = String.valueOf(rs.getInt("log_idfuncionalidad"));
                arrayTemp[5] = String.valueOf(rs.getInt("log_idaplicacion"));
                arrayTemp[6] = String.valueOf(rs.getInt("log_idtipoevento"));
                arrayTemp[7] = rs.getString("desc_larga");
                arrayTemp[8] = rs.getString("desc_corta");
                arrayTemp[9] = String.valueOf(rs.getInt("idrol"));
                arrayTemp[10] = String.valueOf(rs.getInt("idmenu"));
                logs.add(arrayTemp);
                
            }
            return logs;
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

}
