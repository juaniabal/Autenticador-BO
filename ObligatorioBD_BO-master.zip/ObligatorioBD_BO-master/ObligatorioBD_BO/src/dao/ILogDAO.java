/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Agroa
 */
public interface ILogDAO {
    int selectSequence();
    int[] insertLogUser(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta);
    int[] insertLogRole(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta,int idRol);
    int[] insertLogFunctionality(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta,int idFunc);
    int[] insertLogMenu(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta, int idmenu);
    int[] insertLogApplication(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta,int idAplicacion);
    int[] insertLogUserApp(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta,int idAplicacion);
    int[] insertLogRoleUser(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta,int idRol);
    int[] insertLogRolMenu(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta,int idRol,int idMenu);
    int[] insertLogPerson(String nomusu, String usuActual,int tipoEvento,String descLarga, String descCorta);
}
