/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Agroa
 */
public interface IRoleUserDao {

    HashMap<Integer,String> selectUserRoles(String usuario);

    int[] insertUserRoles(String[] userRole, String user);

    int[] updateUserRoles(String nomusu, int idRol);

    int[] deleteRoles(String nomusu, int idrol);

    boolean checkAvailability(String userName);

    ArrayList<String> selectCurrentUserRoleS(String nomusu);
    
    int[] deletePermanently(String nomusu,int idrol);
}
