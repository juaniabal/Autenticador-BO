/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.DatabaseConnection;
import models.Functionality;

/**
 *
 * @author Agroa
 */
public class FunctionalityDAO implements IFunctionalityDAO {

    private String insert = "INSERT INTO funcionalidad (idfuncionalidad,nombre,idmenu) VALUES ";
    private String update = "UPDATE FUNCIONALIDAD SET ";
    private String delete = "DELETE FROM FUNCIONALIDAD WHERE ";
    DatabaseConnection dbconn = DatabaseConnection.getInstance();

    @Override
    public HashMap<Integer, String> selectFuncionalities() {
        Connection con = null;
        try {
            HashMap<Integer, String> selectedItems = new HashMap<>();
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery("select * from funcionalidad");
            while (rs.next()) {
                selectedItems.put(rs.getInt("idfuncionalidad"), rs.getString("nombre"));
            }
            return selectedItems;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] updateFunctionality(Functionality func) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            String updateFuncMenu = "";
            if(func.getIdMenu()!=0){
            updateFuncMenu = update + "idmenu=" + func.getIdMenu() + " where idfuncionalidad = " + func.getIdFunc();
            s.addBatch(updateFuncMenu);
            }
            String updateFuncName = "";
            if(!func.getNombreFunc().equals("")){
                updateFuncName = update + "nombre='" + func.getNombreFunc() + "' where idfuncionalidad = " + func.getIdFunc();
                s.addBatch(updateFuncName);
            }
            //s.addBatch(update + "idmenu=" + func.getIdMenu() + " where idfuncionalidad = " + func.getIdFunc());
            int[] result = s.executeBatch();
             LogController lc = new LogController();
            lc.insertLogFunctionality("", dbconn.getUser(), 20, "El usuario: " + dbconn.getUser() + "ha actualizado la funcionalidad: " +func.getIdFunc()+"-"+func.getNombreFunc(), "Update functionality", func.getIdFunc());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se actalizó la funcionalidad correctamente");
            return result;
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error inesperado");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] deleteFunctionality(Functionality func) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(delete + " idfuncionalidad = " + func.getIdFunc());
            int[] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogFunctionality("", dbconn.getUser(), 19, "El usuario: " + dbconn.getUser() + "ha eliminado la funcionalidad: " +func.getIdFunc()+"-"+func.getNombreFunc(), "Delete functionality", func.getIdFunc());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se eliminó la funcionalidad correctamente");
            return result;

        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }

    }

    @Override
    public int[] insertFunctionality(Functionality func) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(insert + "(" + func.getIdFunc() + "," + "'" + func.getNombreFunc() + "'" + "," + func.getIdMenu() + ")");
            int[] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogFunctionality("", dbconn.getUser(), 18, "El usuario: " + dbconn.getUser() + " ha creado la funcionalidad: " +func.getIdFunc()+"-"+func.getNombreFunc() + " asociada al menú: " + func.getIdMenu(), "Create functionality", func.getIdFunc());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se creó la funcionalidad correctamente");
            return result;
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

}
