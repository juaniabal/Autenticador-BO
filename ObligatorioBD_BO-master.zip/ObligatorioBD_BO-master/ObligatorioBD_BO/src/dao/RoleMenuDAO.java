/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class RoleMenuDAO implements IRoleMenuDAO {

    DatabaseConnection dbConn = DatabaseConnection.getInstance();
    private String insert = "INSERT INTO ROL_MENU VALUES (";
    private String currentMenus = "SELECT * FROM VW_QRY_ROL_MENU WHERE IDROL = ";
    private String deleteMenu = "DELETE FROM ROL_MENU WHERE ";

    @Override
    public ArrayList<String> selectRoleMenus() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] insertRoleMenus(String[] menus, int idRol) {
        Connection conn = null;
        try {
            conn = dbConn.getCurrentConnection();
            Statement s = conn.createStatement();
            for (String strRolUsu : menus) {
                String[] splitRolUsu = strRolUsu.split("-");
                s.addBatch(insert + Integer.parseInt(splitRolUsu[0]) + "," + idRol + ")");
            }
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            for (String strRolUsu : menus) {
                String[] splitRolUsu = strRolUsu.split("-");
                lc.insertLogRolMenu(null, dbConn.getUser(), 16, "El usuario " + dbConn.getUser() + " ha asociado el menu " + splitRolUsu[0] + " al rol " + idRol, "Asociate rol menu", idRol, Integer.parseInt(splitRolUsu[0]));
            }

            conn.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return batch;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(RoleMenuDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
            Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public int[] updateRoleMenus(String nomusu, int idRol) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] deleteMenu(String idmenu, int idrol) {
        Connection conn = null;
        try {
            conn = dbConn.getCurrentConnection();
            Statement s = conn.createStatement();
            s.addBatch(deleteMenu + " idrol = " + idrol + " and idmenu = " + idmenu);
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();

            lc.insertLogRolMenu(null, dbConn.getUser(), 17, "El usuario " + dbConn.getUser() + " ha eliminado el rol asociado " + idrol + " al menu " + idmenu, "Delete rol menu", idrol, Integer.parseInt(idmenu));

            conn.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return batch;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(RoleMenuDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
            Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public ArrayList<String> selectCurrentRoleMenus(int idMenu, int idRol) {
        try {
            ArrayList<String> data = new ArrayList<>();
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery(currentMenus + idRol);

            while (rs.next()) {
                data.add(rs.getInt("idmenu") + "-" + rs.getString("menu_name"));
            }
            return data;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

}
