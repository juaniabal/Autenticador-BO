/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.Mocks;

import dao.IApplicationDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import models.Application;




/**
 *
 * @author Agroa
 */
public class ApplicationDaoFake implements IApplicationDAO {
    private  HashMap<Integer,String> idApplications = new  HashMap<>();
    public int[] updateApplication() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public int[] insertApplication(int id, String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int[] deleteApplication() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean selectApplicationFake() {
                try {
            Class.forName("org.postgresql.Driver");
            HashMap<Integer, String> roles = new HashMap<>();
            String url = "jdbc:postgresql://192.168.56.102:5432/proyecto";
            try (Connection con = DriverManager.getConnection(url, "postgres", "BlackMirror2020");
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery("select * from aplicacion");
                while(rs.next()){
                    this.getIdApplications().put(rs.getInt("idaplicacion"),rs.getString("nombre"));
                }

                rs.close();
                s.close();
                con.close();
            }
            return true;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * @return the idApplications
     */
    public HashMap<Integer,String> getIdApplications() {
        return idApplications;
    }

    @Override
    public int[] insertApplication(Application application) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] updateApplication(Application application) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] deleteApplication(Application application) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public HashMap<Integer, String> selectApplication() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
