/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.Mocks;

import dao.IRoleDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import models.DatabaseConnection;
import models.Role;

/**
 *
 * @author Agroa
 */
public class RolesDaoMock implements IRoleDAO {

    private HashMap<Integer, String> idRoles = new HashMap<>();
    private String role = null;
    private String createUser = "create role " + role + " with standardUser";
    private String update = "UPDATE ROL SET ";
    private String select = "SELECT * FROM ROL WHERE ";
    private String delete = "DELETE FROM ROL WHERE ";
    DatabaseConnection dbConn = DatabaseConnection.getInstance();

    @Override
    public int[] createRole(String ID, String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] insertRole(Role role) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] deleteRole(Role role) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public HashMap<Integer, String> selectRole() {
        try {
            Class.forName("org.postgresql.Driver");
            HashMap<Integer, String> roles = new HashMap<>();
            String url = "jdbc:postgresql://192.168.56.102:5432/proyecto";
            try (Connection con = DriverManager.getConnection(url, dbConn.getUser(), dbConn.getPassword());
                    Statement s = con.createStatement()) {

                ResultSet rs = s.executeQuery("select * from rol");
                while (rs.next()) {
                    this.getIdRoles().put(rs.getInt("idrol"), rs.getString("nombre"));
                }

                rs.close();
                s.close();
                con.close();
            }
            return null;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    /**
     * @return the idRoles
     */
    public HashMap<Integer, String> getIdRoles() {
        return idRoles;
    }

    @Override
    public int[] updateRole(Role role) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
