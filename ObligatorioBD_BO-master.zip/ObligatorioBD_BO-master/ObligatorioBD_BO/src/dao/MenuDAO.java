/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.DatabaseConnection;
import models.Menu;

/**
 *
 * @author Agroa
 */
public class MenuDAO implements IMenuDAO {

    private String insert = "INSERT INTO menu (idmenu,nombre,idaplicacion) VALUES ";
    private String update = "UPDATE MENU SET ";
    private String delete = "DELETE FROM MENU WHERE ";
    DatabaseConnection dbconn = DatabaseConnection.getInstance();

    @Override
    public int[] insertMenu(Menu menu) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(insert + "(" + menu.getIdmenu() + "," + "'" + menu.getNombre() + "'" + "," + menu.getIdaplicacion() + ")");
            int[] result = s.executeBatch();
             LogController lc = new LogController();
            lc.insertLogMenu("", dbconn.getUser(), 13, "El usuario: " + dbconn.getUser() + "ha creado el menu: " +menu.getIdmenu()+"-"+menu.getNombre() +" con la app: " + menu.getIdaplicacion(), "Update menu", menu.getIdmenu());
            con.commit();
            //ResultSet rs = s.executeQuery(insert + "(" + menu.getIdmenu() + "," + "'" + menu.getNombre()+ "'" + "," + menu.getIdaplicacion() + ")");
            JOptionPane.showMessageDialog(null, "Se creó el menú correctamente");
            return result;
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] updateMenuName(Menu menu) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(update + "nombre='" + menu.getNombre() + "' where idmenu = " + menu.getIdmenu());
            //ResultSet rs = s.executeQuery(update + "nombre='"+menu.getNombre() +"' where idmenu = " + menu.getIdmenu());
            int[] result = s.executeBatch();
             LogController lc = new LogController();
            lc.insertLogMenu("", dbconn.getUser(), 15, "El usuario: " + dbconn.getUser() + "ha actualizado el nombre del menu: " +menu.getIdmenu() +" al nombre: " + menu.getNombre(), "Update menu", menu.getIdmenu());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se actualizó el menú correctamente");
            return result;
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public HashMap<Integer, String> selectMenu() {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            HashMap<Integer, String> selectedItems = new HashMap<>();

            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery("select * from menu");
            while (rs.next()) {
                selectedItems.put(rs.getInt("idmenu"), rs.getString("nombre"));
            }

            return selectedItems;

        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }

        return null;
    }

    @Override
    public int[] updateMenuApplication(Menu menu) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();

            //ResultSet rs = s.executeQuery(update + "idaplicacion=" + menu.getIdaplicacion() + " where idmenu = " + menu.getIdmenu());
            s.addBatch(update + "idaplicacion=" + menu.getIdaplicacion() + " where idmenu = " + menu.getIdmenu());
            int[] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogMenu("", dbconn.getUser(), 15, "El usuario: " + dbconn.getUser() + "ha actualizado la aplicacion asociada desede el menu: " +menu.getIdmenu() +" con la app: " + menu.getIdaplicacion(), "Update menu", menu.getIdmenu());
            con.commit();
            return result;

        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] deleteMenu(Menu menu) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();

            //ResultSet rs = s.executeQuery(delete + " idmenu = " + menu.getIdmenu());
            s.addBatch(delete + " idmenu = " + menu.getIdmenu());
            int[] result = s.executeBatch();
             LogController lc = new LogController();
            lc.insertLogMenu("", dbconn.getUser(), 14, "El usuario: " + dbconn.getUser() + "ha eliminado el menu: " +menu.getIdmenu()+"-"+menu.getNombre(), "Delete menu", menu.getIdmenu());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se eliminó el menú correctamente");
            return result;

        } catch (SQLException e) {
              try {
                con.rollback();
                e.getNextException();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ócurrió un error inesperado");
            System.out.println(e.getMessage());
            return null;
        }
    }

}
