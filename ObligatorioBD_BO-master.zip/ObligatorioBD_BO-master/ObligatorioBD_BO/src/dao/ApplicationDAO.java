/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.Application;
import models.DatabaseConnection;
import models.Menu;

/**
 *
 * @author Agroa
 */
public class ApplicationDAO implements IApplicationDAO {

    private String insert = "INSERT INTO aplicacion (idaplicacion,nombre) VALUES ";
    private String update = "UPDATE aplicacion SET ";
    private String delete = "DELETE FROM APLICACION WHERE ";
    DatabaseConnection dbconn = DatabaseConnection.getInstance();

    @Override
    public int[] insertApplication(Application application) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(insert + "(" + application.getIdaplicacion() + "," + "'" + application.getNombre() + "')");
            //ResultSet rs = s.executeQuery(insert + "(" + application.getIdaplicacion()+ "," + "'" + application.getNombre()+ "')");
            int[] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogApplication(null, dbconn.getUser(), 10, "El usuario " + dbconn.getUser() + " ha creado la aplicacion " + application.getNombre() + " con id " + application.getIdaplicacion(), "Create app", application.getIdaplicacion());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se creó la aplicacion correctamente");
            return result;

        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public HashMap<Integer, String> selectApplication() {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            HashMap<Integer, String> selectedItems = new HashMap<>();

            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery("select * from aplicacion");
            while (rs.next()) {
                selectedItems.put(rs.getInt("idaplicacion"), rs.getString("nombre"));
            }

            return selectedItems;

        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }

        return null;
    }

    @Override
    public int[] deleteApplication(Application application) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(delete + " idaplicacion = " + application.getIdaplicacion());
            //ResultSet rs = s.executeQuery(delete + " idaplicacion = " + application.getIdaplicacion());
            int[] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogApplication(null, dbconn.getUser(), 11, "El usuario " + dbconn.getUser() + " ha eliminado la aplicacion " + application.getNombre() + " con id " + application.getIdaplicacion(), "Delete app", application.getIdaplicacion());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se eliminó la aplicacion correctamente");

            return result;
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error en la eliminación");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] updateApplication(Application application) {
        Connection con = null;
        try {
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(update + " nombre='" + application.getNombre() + "' where idaplicacion = " + application.getIdaplicacion());
            //ResultSet rs = s.executeQuery(update + "nombre='" + application.getNombre() + "' where idaplicacion = " + application.getIdaplicacion());
            int[] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogApplication(null, dbconn.getUser(), 10, "El usuario " + dbconn.getUser() + " ha modificado la aplicacion para el nombre " + application.getNombre() , "Update app", application.getIdaplicacion());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se actualizó la aplicacion correctamente");
            return result;
            
            
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }
}
