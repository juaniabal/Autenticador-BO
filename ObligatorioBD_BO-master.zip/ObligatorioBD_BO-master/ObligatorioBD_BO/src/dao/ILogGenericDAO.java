/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Agroa
 */
public interface ILogGenericDAO {
    int roleSaveChanges();
    int userSaveChanges();
    int roleUserSaveChanges();
    int roleMenuSaveChanges();
    int menuSaveChanges();
    int functionalitieSaveChanges();
    int personSaveChanges();
}
