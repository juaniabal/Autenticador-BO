/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.Role;
import models.DatabaseConnection;

/**
 *
 * @author juanizquierdo
 */
public class RoleDAO implements IRoleDAO {

    private String insert = "INSERT INTO rol (idRol,nombre) VALUES ";
    private String update = "UPDATE ROL SET ";
    private String delete = "DELETE FROM ROL WHERE ";
    DatabaseConnection dbconn = DatabaseConnection.getInstance();

    @Override
    public int[] createRole(String ID, String name) {
        Connection con = null;
        try {

            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(insert + "(" + ID + "," + "'" + name + "')");
            int [] result =  s.executeBatch();
            con.commit();
            JOptionPane.showMessageDialog(null, "Se creó el rol correctamente");
            return result;
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] updateRole(Role role) {
        Connection con = null;
        try {

            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(update + "nombre='" + role.getName() + "' where idrol = " + role.getId());
//            ResultSet rs = s.executeQuery(update + "nombre='" + role.getName() + "' where idrol = " + role.getName());
            int [] result =  s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogRole("", dbconn.getUser(), 9, "El usuario: " + dbconn.getUser() + "ha actualizado el nombre del rol: " + role.getId() +" cambiando el nombre a: " + role.getName(), "Update rol", role.getId());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se actualizó el rol correctamente");
            return result;
            
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] insertRole(Role role) {
        Connection con = null;
        try {

            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(insert + "(" + role.getId() + "," + "'" + role.getName() + "')");
            
            int [] result =  s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogRole("", dbconn.getUser(), 7, "El usuario: " + dbconn.getUser() + "ha agregado el rol: " + role.getId(), "Create rol", role.getId());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se creó el rol correctamente");
            return result;
            //ResultSet rs = s.executeQuery(insert + "(" + role.getId() + "," + "'" + role.getName() + "'" + "," + role.getId() + ")");
            
            
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int[] deleteRole(Role role) {
        Connection con = null;
        try {

            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(delete + " idrol = " + role.getId());
            int [] result = s.executeBatch();
            LogController lc = new LogController();
            lc.insertLogRole("", dbconn.getUser(), 8, "El usuario: " + dbconn.getUser() + "ha eliminado el rol: " + role.getId(), "Delete rol", role.getId());
            con.commit();
            JOptionPane.showMessageDialog(null, "Se eliminó el rol correctamente");
            return result;
            //ResultSet rs = s.executeQuery(delete + " idrol = " + role.getId());
            //con.commit();

           
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            e.getNextException();
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public HashMap<Integer, String> selectRole() {
        Connection con = null;
        try {
            HashMap<Integer, String> selectedItems = new HashMap<>();
            con = dbconn.getCurrentConnection();
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from rol");
            while (rs.next()) {
                selectedItems.put(rs.getInt("idrol"), rs.getString("nombre"));
            }
            return selectedItems;
        } catch (SQLException e) {
              try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(e.getMessage());

        }
        return null;
    }

}
