/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LogController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class RoleUserDao implements IRoleUserDao {

    DatabaseConnection dbConn = DatabaseConnection.getInstance();
    private String insert = "INSERT INTO ROL_USUARIO VALUES (";
    private String update = "UPDATE ROL_USUARIO SET REG_STATUS = 0";
    private String updateReg1 = "update rol_usuario set reg_status = 1";
    private String updateUser = "UPDATE USUARIO SET SEGUNDOAUTORIZADOR = ";
    private String updateUserFirst = "UPDATE USUARIO SET PRIMERAUTORIZADOR = ";
    private String checkAvailable = "SELECT * FROM USUARIO WHERE NOMUSU = ";
    private String currentRoles = "SELECT * FROM VW_QRY_USER_ROLES WHERE NOMUSU = ";
    private String deleteRoleUser = "DELETE FROM ROL_USUARIO WHERE ";
    // private String insertDelete = "INSERT INTO ROL_USUARIO (REG_STATUS,DELETERU) VALUES (";
    private String updateDelete = "UPDATE ROL_USUARIO SET DELETERU = ";

    @Override
    public HashMap<Integer,String> selectUserRoles(String usuario) {
        try {
            HashMap<Integer,String> userRoles = new HashMap<>();
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery("select * from rol_usuario where rol_usu_nomusu = '" + usuario + "'");
            while (rs.next()) {
                userRoles.put(rs.getInt("rol_usu_idrol"),rs.getString("rol_usu_nomusu"));
            }
            return userRoles;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }
    
    public boolean selectUserRoleAlready(String usuario, int idRol){
         try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            boolean tiene = false;
            ResultSet rs = s.executeQuery("select * from rol_usuario where rol_usu_nomusu = '" + usuario + "' and rol_usu_idrol = " + idRol);
            while (rs.next()) {
                tiene = true;
            }
            return tiene;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return true;
        }
    }

    @Override
    public int[] insertUserRoles(String[] rolUsu, String user) {
        Connection conn = dbConn.getCurrentConnection();
        try {
            Statement s = conn.createStatement();
            for (String strRolUsu : rolUsu) {
                String[] splitRolUsu = strRolUsu.split("-");
                s.addBatch(insert + "'" + user + "'," + splitRolUsu[0] + ",1)");
            }
            int[] batch = s.executeBatch();
             UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
             for (String strRolUsu : rolUsu) {
                 String[] splitRolUsu = strRolUsu.split("-");
                lc.insertLogRoleUser(user, dbConn.getUser(), 3, "El usuario " + dbConn.getUser() + " ha agregado el rol " + splitRolUsu[0] + " al usuario " + user, "Upgrade rol user",Integer.parseInt(splitRolUsu[0]));
             }
            boolean check = udao.checkPendingAuthorizations(user);
            if(check){
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + user + "'");
                s.addBatch(updateUserFirst + "'" + dbConn.getUser() + "' where nomusu = '" + user + "'" );
                s.executeBatch();
            }/*else{
            s.clearBatch();
            s.addBatch(updateUser + "null" + " where nomusu = '" + user + "'" );
            s.addBatch(updateUserFirst + "null" + "' where nomusu = '" + user + "'" );
            s.executeBatch();
            }*/
            conn.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return batch;
        } catch (SQLException ex) {
              try {
                conn.rollback();
            } catch (SQLException e) {
                Logger.getLogger(ApplicationDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public int[] updateUserRoles(String nomusu, int idRol) {
        int[] result = null;
        Connection con = null;
        try {
            con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            s.addBatch(update + " where rol_usu_idrol = " + idRol + " and rol_usu_nomusu = '" + nomusu + "'");
            s.addBatch(updateUser + "'" + dbConn.getUser() + "' where nomusu = '" + nomusu + "'");
            result = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            lc.insertLogRoleUser(nomusu, dbConn.getUser(), 3, "El usuario " + dbConn.getUser() + " ha confirmado el rol " + idRol + " al usuario " + nomusu, "Upgrade rol user",idRol);
            boolean check = udao.checkPendingAuthorizations(nomusu);
            if(check){
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            }else{
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'" );
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + nomusu + "'" );
                s.executeBatch();
            }
            con.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return result;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            System.out.println(e.getMessage());
            e.getNextException();
            try {
                con.rollback();
            } catch (SQLException ex) {
                Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
            return result;
        }
    }

    @Override
    public int[] deleteRoles(String nomusu,int idrol) {
        Connection conn = dbConn.getCurrentConnection();
        try {
            Statement s = conn.createStatement();
            String updateDeleteNew = updateDelete + "'" + deleteRoleUser + "rol_usu_nomusu = ''" 
                    + nomusu + "'' and rol_usu_idrol = " + idrol + "'" + " where rol_usu_nomusu = '" + nomusu + "' and rol_usu_idrol = " + idrol;
            //s.execute(updateDeleteNew);
            //s.execute(updateReg1 + " where rol_usu_nomusu = '" + nomusu + "' and rol_usu_idrol = " + idrol);
            s.addBatch(updateDeleteNew);
            s.addBatch(updateReg1 + " where rol_usu_nomusu = '" + nomusu + "' and rol_usu_idrol = " + idrol);
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            lc.insertLogRoleUser(nomusu, dbConn.getUser(), 5, "El usuario " + dbConn.getUser() + " ha quitado el rol " + idrol + " al usuario " + nomusu, "Downgrade rol user",idrol);
            boolean check = udao.checkPendingAuthorizations(nomusu);
            if(check){
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            }else{
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'" );
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + nomusu + "'" );
                s.executeBatch();
            }
            conn.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return batch;
        } catch (SQLException ex) {
            Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex);
            ex.getNextException();
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        return null;
    }

    @Override
    public boolean checkAvailability(String userName) {
        try {
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();
            boolean available = true;
            ResultSet rs = s.executeQuery(checkAvailable + "'" + userName + "' and primerautorizador is not null and segundoautorizador is null");
            while (rs.next()) {
                available = false;
            }
            return available;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public ArrayList<String> selectCurrentUserRoleS(String nomusu) {
        try {
            ArrayList<String> data = new ArrayList<>();
            Connection con = dbConn.getCurrentConnection();
            Statement s = con.createStatement();

            ResultSet rs = s.executeQuery(currentRoles + "'" + nomusu + "'");
            
            while (rs.next()) {
                data.add(rs.getInt("idrol") + "-" + rs.getString("nombre"));
            }
            return data;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }
    @Override
    public int[] deletePermanently(String nomusu, int idrol) {
        Connection conn = dbConn.getCurrentConnection();
        try {
            Statement s = conn.createStatement();
            
            s.addBatch(deleteRoleUser + "rol_usu_nomusu = '" + nomusu + "'and rol_usu_idrol = " + idrol);
            s.addBatch(updateUser + "'" + dbConn.getUser() + "' where nomusu = '" + nomusu + "'");
            int[] batch = s.executeBatch();
            UtilsDAO udao = new UtilsDAO();
            LogController lc = new LogController();
            lc.insertLogRoleUser(nomusu, dbConn.getUser(), 5, "El usuario " + dbConn.getUser() + " ha eliminado permanentemente el rol " + idrol + " al usuario " + nomusu, "Upgrade rol user",idrol);
            boolean check = udao.checkPendingAuthorizations(nomusu);
            if(check){
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'");
                s.executeBatch();
            }else{
                s.clearBatch();
                s.addBatch(updateUser + "null" + " where nomusu = '" + nomusu + "'" );
                s.addBatch(updateUserFirst + "null" + " where nomusu = '" + nomusu + "'" );
                s.executeBatch();
            }
            conn.commit();
            JOptionPane.showMessageDialog(null, "Operación completa");
            return batch;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error");
            Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex);
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(RoleUserDao.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        return null;
    }

}
