/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.LogDAO;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class LogController implements ILogController{
    LogDAO log = new LogDAO();
    DatabaseConnection dbconn = DatabaseConnection.getInstance();
    @Override
    public int selectSequence() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] insertLogUser(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta) {
        return log.insertLogUser(nomusu, dbconn.getUser(), tipoEvento, descLarga, descCorta);
    }

    @Override
    public int[] insertLogRole(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta,int idrol) {
        return log.insertLogRole(nomusu, usuActual, tipoEvento, descLarga, descCorta, idrol);
    }

    @Override
    public int[] insertLogFunctionality(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idFunc) {
        return log.insertLogFunctionality(nomusu, usuActual, tipoEvento, descLarga, descCorta,idFunc);
    }

    @Override
    public int[] insertLogMenu(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idmenu) {
        return log.insertLogMenu(nomusu, usuActual, tipoEvento, descLarga, descCorta, idmenu);
    }

    @Override
    public int[] insertLogApplication(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta,int idAplicacion) {
        return log.insertLogApplication(nomusu, usuActual, tipoEvento, descLarga, descCorta,idAplicacion);
    }

    @Override
    public int[] insertLogUserApp(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta,int idAplicacion) {
        return log.insertLogUserApp(nomusu, usuActual, tipoEvento, descLarga, descCorta,idAplicacion);
    }

    @Override
    public int[] insertLogRoleUser(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta, int idRol) {
        return log.insertLogRoleUser(nomusu, usuActual, tipoEvento, descLarga, descCorta,idRol);
    }

    @Override
    public int[] insertLogRolMenu(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta,int idRol,int idMenu) {
        return log.insertLogRolMenu(nomusu, usuActual, tipoEvento, descLarga, descCorta,idRol,idMenu);
    }

    @Override
    public int[] insertLogPerson(String nomusu, String usuActual, int tipoEvento, String descLarga, String descCorta) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
