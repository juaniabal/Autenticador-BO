/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.RoleUserDao;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;

/**
 *
 * @author Agroa
 */
public class RoleUserController implements IRoleUserController{
    private RoleUserDao rud = new RoleUserDao();
    @Override
    public int[] insertUserRole(String[] userRoles,String user) {
        if(user.length()>0){
            return rud.insertUserRoles(userRoles, user);
        }else{
            JOptionPane.showMessageDialog(null, "Hay datos incoherentes en el sistema");
        }return null;
    }

    @Override
    public HashMap<Integer,String> selectUserRoles(String usuario) {
        return rud.selectUserRoles(usuario);
    }

    @Override
    public int[] updaetUserRoles(String[] userRoles) {
        return rud.updateUserRoles(userRoles[0], Integer.parseInt(userRoles[2]));
    }

    @Override
    public int[] deleteUserRoles(String nomusu,int idrol) {
        return rud.deleteRoles(nomusu, idrol);
    }

    @Override
    public boolean checkAvailable(String userName) {
        return rud.checkAvailability(userName);
    }

    @Override
    public ArrayList<String> currentRoles(String nomusu) {
        return rud.selectCurrentUserRoleS(nomusu);
    }

    @Override
    public int[] deletePermanently(String nomusu, int idrol) {
        return rud.deletePermanently(nomusu, idrol);
    }
    
}
