/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ApplicationDAO;
import dao.IApplicationDAO;
import dao.MenuDAO;
import dao.Mocks.ApplicationDaoFake;
import java.util.HashMap;
import java.util.Map;
import models.CodeResponse;
import models.Menu;

/**
 *
 * @author Agroa
 */
public class MenuController implements IMenuController {

    @Override
    public CodeResponse insertMenu(Menu menu) {
        try {
            IApplicationDAO app = new ApplicationDAO();
            app.selectApplication();
            MenuDAO menuDao = new MenuDAO();
            int response = menuDao.insertMenu(menu)[0];
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error de sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

  

    @Override
    public CodeResponse updateMenu(Menu menu) {
        try {
            MenuDAO menuDAO = new MenuDAO();
            int response = 101;
            if (!menu.getNombre().equals("")) {
                response = menuDAO.updateMenuName(menu)[0];
            }
            if (menu.getIdaplicacion() != 0) {
                response = menuDAO.updateMenuApplication(menu)[0];
            }
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error de sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

    @Override
    public HashMap<Integer, String> selectMenu() {
        MenuDAO menuDao = new MenuDAO();
        HashMap<Integer, String> response = menuDao.selectMenu();
        return response;
    }

    public String[] getMenus(HashMap<Integer, String> menus) {
        if (menus != null) {
            String[] arrMenus = new String[menus.size()];
            int i = 0;
            for (Map.Entry hashes : menus.entrySet()) {
                arrMenus[i] = hashes.getKey() + "-" + hashes.getValue();
                i++;
            }
            return arrMenus;
        }return null;
    }

    @Override
    public CodeResponse deleteMenu(Menu menu) {
        try {
            MenuDAO menuDao = new MenuDAO();
            int response = menuDao.deleteMenu(menu)[0];
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error de sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

}
