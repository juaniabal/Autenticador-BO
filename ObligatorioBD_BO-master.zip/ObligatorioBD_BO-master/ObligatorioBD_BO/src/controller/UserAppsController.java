/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.RoleUserDao;
import dao.UserApplicationDAO;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Agroa
 */
public class UserAppsController implements IAppUserController {
    private UserApplicationDAO uad = new UserApplicationDAO();
    @Override
    public int[] insertUserApp(String[] userApps, String user) {
        if(user.length()>0){
            return uad.insertUserApps(userApps, user);
        }else{
            JOptionPane.showMessageDialog(null, "Hay datos incoherentes en el sistema");
        }return null;
    }

    @Override
    public boolean selectUserApps() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int[] updaetUserApps(String[] userApps) {
        return uad.updateUserApps(userApps[0], Integer.parseInt(userApps[2]));
    }

    @Override
    public int[] deleteUserApps(String nomusu, int idrol) {
        return uad.deleteUserApps(nomusu, idrol);
    }

    @Override
    public ArrayList<String> currentApps(String nomusu) {
        
        return uad.currentApps(nomusu);
    }

    @Override
    public int[] deletePermanently(String nomusu, int idaplicacion) {
        return uad.deletePermantly(nomusu, idaplicacion);
    }

    @Override
    public boolean checkAvailable(String userName) {
        return uad.checkAvailable(userName);
    }

}
