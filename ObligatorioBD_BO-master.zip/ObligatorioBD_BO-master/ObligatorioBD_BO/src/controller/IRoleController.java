/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.HashMap;
import models.CodeResponse;
import models.Role;

/**
 *
 * @author juanizquierdo
 */
public interface IRoleController {

    /**
     * Funcion que llama al RoleDAO para crear un Rol de la tabla ROL.
     *
     * @param role
     * @return
     */
    CodeResponse createRole(Role role);

    /**
     * Funcion que llama al RoleDAO para modificar un Rol de la tabla ROL.
     *
     * @param role
     * @return
     */
    CodeResponse updateRole(Role role);

    /**
     * Funcion que llama al RoleDAO para seleccionar todos los Roles de la tabla
     * ROL.
     *
     * @return
     */
    public HashMap<Integer, String> selectRole();

    /**
     * Funcion que llama al RoleDAO para borrar un Rol de la tabla ROL.
     *
     * @param role
     * @return
     */
    CodeResponse deleteRole(Role role);

}
