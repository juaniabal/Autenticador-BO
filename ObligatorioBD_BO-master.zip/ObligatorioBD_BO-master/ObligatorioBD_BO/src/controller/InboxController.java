/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.InboxDao;
import java.util.ArrayList;

/**
 *
 * @author Agroa
 */
public class InboxController implements IInboxController {

    InboxDao inboxDao = new InboxDao();

    @Override
    public ArrayList<String> selectPendingAuthorizationRoleUser() {
        return inboxDao.selectPendingAuthorizationRoleUser();
    }

    @Override
    public ArrayList<String> selectPendingAuthorizationUserApps() {
        return inboxDao.selectPendingAuthorizationUserApps();
    }

    @Override
    public ArrayList<String> selectPendingAuthorizationRoleMenus() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<String> selectPendingAuthorizationUsers() {
        return inboxDao.selectPendingAuthorizationUsers();
    }

}
