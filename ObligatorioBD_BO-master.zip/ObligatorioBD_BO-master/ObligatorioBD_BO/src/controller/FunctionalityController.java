/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.FunctionalityDAO;
import dao.IFunctionalityDAO;
import java.util.HashMap;
import java.util.Map;
import models.CodeResponse;
import models.Functionality;

/**
 *
 * @author Agroa
 */
public class FunctionalityController implements IFunctionalityController {

    @Override
    public HashMap<Integer, String> selectFuncionalities() {
        FunctionalityDAO funcDAO = new FunctionalityDAO();
        HashMap<Integer, String> response = funcDAO.selectFuncionalities();
        return response;

    }

    @Override
    public CodeResponse updateFunctionality(Functionality func) {
        try {
            IFunctionalityDAO funcDAO = new FunctionalityDAO();
            int response = 101;
            if (!func.getNombreFunc().equals("")) {
                response = funcDAO.updateFunctionality(func)[0];
            }
            if (func.getIdMenu() != 0) {
                response = funcDAO.updateFunctionality(func)[0];
            }
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error del Sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }

    }

    @Override
    public CodeResponse deleteFunctionality(Functionality func) {
        try {
            IFunctionalityDAO funcDAO = new FunctionalityDAO();
            int response = funcDAO.deleteFunctionality(func)[0];
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error del Sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }

    }

    @Override
    public CodeResponse insertFunctionality(Functionality func) {
        try {
            IFunctionalityDAO funcDAO = new FunctionalityDAO();
            int response = funcDAO.insertFunctionality(func)[0];
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error del Sistema");
            }
        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

    /**
     *
     * @param func
     * @return
     */
    public String[] getFunctionalities(HashMap<Integer, String> func) {
        if (func != null) {
            String[] arrFunc = new String[func.size()];
            int i = 0;
            for (Map.Entry hashes : func.entrySet()) {
                arrFunc[i] = hashes.getKey() + "-" + hashes.getValue();
                i++;
            }
            return arrFunc;
        }
        return null;
    }

    public HashMap<Integer, String> getIdMenu() {
        IMenuController imc = new MenuController();
        HashMap<Integer,String> arr  = imc.selectMenu();
        return arr;
    }
}
