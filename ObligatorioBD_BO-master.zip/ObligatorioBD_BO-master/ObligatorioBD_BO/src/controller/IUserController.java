/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;

/**
 *
 * @author Agroa
 */
public interface IUserController {
    boolean createUser(String user, String contrasena,String usuario,String contrasenaUsuario,String[] atributos);
    boolean modifyUser(String user);
    int[] deleteuser(String user);
    boolean createPerson(String usuario, String contrasena, String[] attributes);
    int insertUser(String[] attributes);
    int[] deletePermanently(String user);
    ArrayList<String> selectPersona();
    
}
