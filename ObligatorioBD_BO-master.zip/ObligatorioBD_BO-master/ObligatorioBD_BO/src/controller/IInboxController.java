/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;

/**
 *
 * @author Agroa
 */
public interface IInboxController {
    ArrayList<String> selectPendingAuthorizationRoleUser();
    ArrayList<String> selectPendingAuthorizationUserApps();
    ArrayList<String> selectPendingAuthorizationRoleMenus();
    ArrayList<String> selectPendingAuthorizationUsers();
}
