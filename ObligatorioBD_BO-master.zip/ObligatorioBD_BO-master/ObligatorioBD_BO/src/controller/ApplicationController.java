/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ApplicationDAO;
import dao.IApplicationDAO;
import dao.MenuDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import models.Application;
import models.CodeResponse;
import models.Menu;

/**
 *
 * @author Agroa
 */
public class ApplicationController implements IApplicationController {

    @Override
    public CodeResponse insertApplication(Application application) {
        try {
            IApplicationDAO app = new ApplicationDAO();//que sea fake
            app.selectApplication();
            IApplicationDAO applicationDao = new ApplicationDAO();
            int[] response = applicationDao.insertApplication(application);
            if (response[0] == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error de sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }
/*
    public HashMap<Integer, String> getIdApp() {
        ApplicationDAO app = new ApplicationDAO();//fake
        app.selectApplication();
        return app.getIdApplications();

    }*/

    @Override
    public CodeResponse updateApplication(Application application) {
        try {
            ApplicationDAO applicationDAO = new ApplicationDAO();
            int response = 101;
            if (!application.getNombre().equals("")) {
                response = applicationDAO.updateApplication(application)[0];
            }
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error de sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

    @Override
    public HashMap<Integer, String> selectApplication() {
        ApplicationDAO applicationDao = new ApplicationDAO();
        HashMap<Integer, String> response = applicationDao.selectApplication();
        return response;
    }

    public String[] getApplication(HashMap<Integer, String> applications) {
        if (applications != null) {
            String[] arrapplications = new String[applications.size()];
            int i = 0;
            for (Map.Entry hashes : applications.entrySet()) {
                arrapplications[i] = hashes.getKey() + "-" + hashes.getValue();
                i++;
            }
            return arrapplications;
        }return null;
    }

    @Override
    public CodeResponse deleteApplication(Application application) {
        try {
            ApplicationDAO applicationDao = new ApplicationDAO();
            int response = applicationDao.deleteApplication(application)[0];
            if (response == 100) {
                return new CodeResponse();
            } else {
                return new CodeResponse(422, "Error de sistema");
            }

        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

}
