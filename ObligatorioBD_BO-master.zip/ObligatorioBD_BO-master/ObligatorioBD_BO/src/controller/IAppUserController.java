/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;

/**
 *
 * @author Agroa
 */
public interface IAppUserController {

    int[] insertUserApp(String[] userApps, String user);

    boolean selectUserApps();

    int[] updaetUserApps(String[] userApps);

    int[] deleteUserApps(String nomusu,int idrol);
    
    ArrayList<String> currentApps(String nomusu);
    
    int[] deletePermanently(String nomusu,int idaplicacion);
    
    boolean checkAvailable(String userName);

}
