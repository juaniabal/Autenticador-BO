/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.HashMap;
import models.CodeResponse;
import models.Functionality;

/**
 *
 * @author Agroa
 */
public interface IFunctionalityController {

    /**
     *
     * @return
     */
    HashMap<Integer, String> selectFuncionalities();

    /**
     *
     * @param func
     * @return
     */
    CodeResponse updateFunctionality(Functionality func);

    /**
     *
     * @param func
     * @return
     */
    CodeResponse deleteFunctionality(Functionality func);

    /**
     *
     * @param func
     * @return
     */
    CodeResponse insertFunctionality(Functionality func);

}
