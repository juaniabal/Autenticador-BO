/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.IRoleDAO;
import dao.RoleDAO;
import java.util.HashMap;
import java.util.Map;
import models.CodeResponse;
import models.Role;

/**
 *
 * @author juanizquierdo
 */
public class RoleController implements IRoleController {

    private IRoleDAO roleDAO;

    public RoleController() {
        this.roleDAO = new RoleDAO();
    }

    @Override
    public CodeResponse createRole(Role role) {
        try {
            int response = roleDAO.insertRole(role)[0];
            return response == 100 ? new CodeResponse() : new CodeResponse(422, "Error de Sistema.");
        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

    @Override
    public CodeResponse updateRole(Role role) {
        try {
            int response = roleDAO.updateRole(role)[0];
            return (response == 100) ? new CodeResponse() : new CodeResponse(422, "Error de Sistema");
        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

    @Override
    public HashMap<Integer, String> selectRole() {
        HashMap<Integer, String> response = roleDAO.selectRole();
        return response;
    }

    @Override
    public CodeResponse deleteRole(Role role) {
        try {
            int response = roleDAO.deleteRole(role)[0];
            return response == 100 ? new CodeResponse() : new CodeResponse(422, "Error de Sistema.");
        } catch (Exception ex) {
            return new CodeResponse(500, ex.getMessage());
        }
    }

    public String[] getRoles(HashMap<Integer, String> roles) {
        if (roles != null) {
            String[] arrRoles = new String[roles.size()];
            int i = 0;
            for (Map.Entry hashes : roles.entrySet()) {
                arrRoles[i] = hashes.getKey() + "-" + hashes.getValue();
                i++;
            }
            return arrRoles;
        }
        return null;
    }

}
