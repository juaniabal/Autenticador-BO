/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.UserDAO;
import java.sql.Date;
import java.util.ArrayList;
import models.DatabaseConnection;

/**
 *
 * @author Agroa
 */
public class UserController implements IUserController{
    DatabaseConnection dbConn = DatabaseConnection.getInstance();
    UserDAO uDao = new UserDAO();
    @Override
    public boolean createUser(String user, String contrasena,String usuario,String contrasenaUsuario,String[] atributos) {
        if(user!=null && contrasena !=null &&usuario!=null&&contrasenaUsuario!=null&&!user.equals("")&&!contrasena.equals("")&&!usuario.equals("")&&contrasenaUsuario!=null){
            String newUser = uDao.createUser(user, contrasena, usuario, contrasenaUsuario);
            if(newUser.equals("OK")) return true;
        }return false;
    }

    @Override
    public boolean modifyUser(String user) {
        return uDao.updateUser(user);
    }

    @Override
    public int[] deleteuser(String user) {
        return uDao.deleteUser(user);
    }

    @Override
    public boolean createPerson(String usuario, String contrasena, String[] attributes) {
        if(usuario!=null&&!usuario.equals("")&&!contrasena.equals("")&& contrasena !=null &&attributes.length>0){
            
            String person = uDao.createPerson(usuario, contrasena, attributes);
            if(person.equals("OK"))return true;
        }return false;
    }

    @Override
    public int insertUser(String[] attributes) {
        
        String insert = "INSERT INTO USUARIO (nomusu,contrasena,ci_persona,idestado,primerautorizador,fechaprimerautorizacion,reg_status) values (";
        Date date = new Date(System.currentTimeMillis());
        insert+= "'" + attributes[0] + "'" + ",'"+ attributes[1]+ "'," + attributes[2] + "," + "4,'" +dbConn.getUser() + "'," + "to_date('" + date + "','YYYY/MM/DD'),1)";
        return uDao.insertUser(insert,attributes);
        
    }

    @Override
    public int[] deletePermanently(String user) {
        return uDao.deletePermantly(user);
    }

    @Override
    public ArrayList<String> selectPersona() {
        return uDao.selectPersonas();
    }
    
}
