    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JFrame;
import models.TableExample;
import views.AdministracionMenu;
import views.AdministracionUsuarios;
import views.ApplicationAdmin;
import views.FunctionalityAdmin;
import views.InboxScreen;
import views.MainScreen;
import views.RoleAdmin;

/**
 *
 * @author Agroa
 */
public class ScreenController implements IScreenController {

    private String[] functionalitiesExample = {"Administracion de Usuarios","Administracion de roles", "Administracion de menues","Administracion de aplicaciones","Administración de funcionalidades","Bandeja de entrada Autorizador","Logs"};
    

    public String[] getFunctionalities() {
        return functionalitiesExample;
    }

    @Override
    public void showMainScreen() {
        MainScreen ms = new MainScreen();
        
        ms.setVisible(true);
    }

    @Override
    public void showUserAdminScreen() {
        AdministracionUsuarios adm = new AdministracionUsuarios();
        adm.setVisible(true);
    }

    @Override
    public void showMenuAdminScreen() {
        AdministracionMenu adm = new AdministracionMenu();
        adm.setVisible(true);
    }

    @Override
    public void showApplicationScreen() {
        ApplicationAdmin appAdm = new ApplicationAdmin();
        appAdm.setVisible(true);
    }

    @Override
    public void showRoleAdminScreen() {
        RoleAdmin radm = new RoleAdmin();
        radm.setVisible(true);
    }
    @Override
    public void hideScreen(JFrame frame) {
        frame.setVisible(false);
    }

    @Override
    public void showFuncAdmin() {
        FunctionalityAdmin fadm = new FunctionalityAdmin();
        fadm.setVisible(true);
    }

    @Override
    public void showInboxScreen() {
        InboxScreen iScreen = new InboxScreen();
        iScreen.setVisible(true);
    }
    
    public void showLogs(){
        new TableExample();
    }
}
