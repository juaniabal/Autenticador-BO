/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Agroa
 */
public interface IRoleUserController {
    int[] insertUserRole(String[] userRoles,String user);
    HashMap<Integer,String> selectUserRoles(String usuario);
    int[] updaetUserRoles(String[] userRoles);
    int[] deleteUserRoles(String nomusu, int idrol);
    boolean checkAvailable(String userName);
    ArrayList<String> currentRoles(String nomusu);
    int[] deletePermanently(String nomusu,int idrol);
        
    
}
